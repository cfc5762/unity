﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Game Count Script
/// This script holds game-level (or scene-level) variables that persist
/// Currently used to hold the number of snowmen who have been obliterated
/// Individual instances of the snowperson prefab have an Explode script, and that Explode script interacts with this GameCount script
/// </summary>

public class GameCount : MonoBehaviour 
{

    // Public variable (visible and editable in the Inspector) that holds the number of snowmen who have been "killed"
    // This value has been set to 0 inside the Inspector
	public int snowpersonCounter;

	// Use this for initialization
	void Start () 
	{

	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}

    // Draw simple GUI text to the screen
    void OnGUI()
    {
        // Change the text color
        GUI.color = Color.black;

        // Change the text size
        GUI.skin.box.fontSize = 20;

        // Draw a box with the text inside in the upper-left corner
        GUI.Box(new Rect(10, 10, 150, 50), "Dead " + snowpersonCounter);
    }
}
