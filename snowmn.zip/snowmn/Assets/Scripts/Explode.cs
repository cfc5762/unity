﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Explode Script
/// This script is placed on the snowperson prefab
/// When a snowperson has been clicked on when the game is playing, they "explode" into 3 pieces
/// This script interacts with the game-level GameCount script on the "SceneManager" object
/// </summary>

public class Explode : MonoBehaviour 
{

    // References to other GameObjects on the snowperson
    // These references are set inside the Inspector instead of here in the script
    // Why?  It's just another way to assign references
	public GameObject top;
	public GameObject mid;
	public GameObject bot;

    // Reference to the game-level empty game object which holds an instance of the GameCount script
    // This is assigned in the Start() method
    // Why? Because the SceneManager game object is not a prefab, and this Explode script is on a prefab and 
    //   Inspector-linking cannot occur by dragging an instance of a non-prefab onto a prefab. 
	private GameObject gm;	

    // reference to the GameCount script on that manager game object
	private GameCount gc;	


	// Use this for initialization
	void Start () 
	{
        // Set the manager reference to another script on the SceneManager object
		gm = GameObject.Find("GameManager");
        // And get a reference to the GameCount script on that GameManager game object
		gc = gm.GetComponent<GameCount> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}

	// OnMouseDown
	void OnMouseDown()
	{
        // Debugging statement
		Debug.Log ("SnowPerson has been clicked");

        /// Add rigidbodies to each of the 3 pieces of the snowperson
        // This enables the physics system when the snowperson is clicked
		top.AddComponent<Rigidbody>();
		mid.AddComponent<Rigidbody>();
		bot.AddComponent<Rigidbody>();

        // Destroy the collider on this snowperson so it can't be clicked on more than once
        //   since the OnMouseDown function won't run unless the game object has a collider
		Destroy (gameObject.GetComponent<Collider>());

        // Add to the snowperson counter in the GameCount script
		gc.snowpersonCounter++;
	}
}
